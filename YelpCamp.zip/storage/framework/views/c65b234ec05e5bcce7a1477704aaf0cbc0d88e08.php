<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
        crossorigin="anonymous"></script>
</head>
<body>
    <div class="container bg-light mt-5 py-5 w-100">
        <form action='/login' method='POST'>
            <div class="row md-12 d-flex justify-content-center">
                <input class="mx-5 w-25 my-2 form-control"  type='text' name='username' placeholder='Enter Username'>
            </div>
            <div class="row md-12 d-flex justify-content-center">
                <input class="mx-5 my-2 w-25 form-control" type='password' name='password' placeholder='........'>
            </div>
            <div class="row md-12 d-flex justify-content-center">
                <button class="w-25 my-3 bg-primary rounded text-light border border-light p-1"  type="submit">Login</button>
            </div>
        </form>
    </div>
</body>
</html> <?php /**PATH C:\Users\AbdulMunim\laravel\YelpCamp\resources\views/login.blade.php ENDPATH**/ ?>