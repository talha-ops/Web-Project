<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>YelpCamp</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
</head>
<body>
    <header>
        <!-- This will have the Top Navigation Bar-->
    </header>
    <section>
        <div class="container ">
            <div class="row">
                <div class="col-md-3">
                    <h1>YelpCamp</h1>
                    <div class="list-group">
                        <li class="list-group-item">Info1</li>
                        <li class="list-group-item">Info2</li>
                        <li class="list-group-item">Info3</li>
                    </div>
                    <div>MAP</div>
                </div>
                <div class="col-md-9">
                    <div class="img-thumbnail" style="width: auto; height: auto;">
                        <img class="mt-1 ml-1 img-fluid w-100 h-100 figure-img rounded"  src="https://media.kare11.com/assets/KARE/images/437173820/437173820_750x422.png"
                            alt="IMG">
                        <div class="figure w-100">
                            <figcaption class="figure-caption" style="float: right;">
                                <h4> Money</h4>
                            </figcaption>
                            <h4><a href=""> Title</a></h4>
                            <p>
                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eius rerum ex, saepe nostrum recusandae fugiat obcaecati reprehenderit quam eveniet sequi impedit tempore ullam, eligendi earum. Dolor rerum aperiam quas quo. Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores expedita quis asperiores omnis, cumque magni nisi ea repudiandae voluptatibus suscipit commodi vitae, rem veritatis esse laboriosam laborum soluta ipsa illum!
                            </p>
                        </div>
                    </div>
                    <div style="height: 50px;">

                    </div>
                    <div class="well bg-light px-3 py-3"> 
                        <div class="text-right">
                            <a class="btn btn-success">Add a Comment</a>
                        </div>
                        <hr>
                        <!--Comment Structure-->
                        <div class="mt-3 px-3 py-3">
                            <div class="row">
                                <div class="col-md-12">
                                    <h4 style="display: inline;">Ahad Shahbaz</h4>
                                    <h6 class="text-right" style="display: inline; float:right">10 days ago</h6>
                                    <p class="mt-4">
                                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Quia vitae fugiat unde autem dignissimos molestias.
                                        Quibusdam magnam, animi rerum possimus nemo nobis rem accusamus explicabo cumque repudiandae corrupti. Quia,
                                        placeat.
                                    </p>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    
                </div>
                
            </div>
        </div>
    </section>
</body>
</html><?php /**PATH C:\Users\AbdulMunim\laravel\YelpCamp\resources\views/campground-detail.blade.php ENDPATH**/ ?>