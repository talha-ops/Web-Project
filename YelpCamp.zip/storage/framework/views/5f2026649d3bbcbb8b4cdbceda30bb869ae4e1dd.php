<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LoginPage</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
        crossorigin="anonymous"></script>
</head>
<body>
    <header>
        <nav class="navbar navbar-light bg-light navbar-expand-sm">
            <div class="navbar-header mx-3">
                <a href="/" class="navbar-brand">Yelp Camp</a>
            </div>
            <button class="navbar-toggler" data-toggle="collapse" data-target="#options">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse d-flex flex-row-reverse mx-4" id="options">
                <ul class="navbar-nav">
                    <!-- <%var currentUser = currentUser;%>

                    <%if(!currentUser){%>
                        <li class="nav-item">
                            <a href = '#'>No Current User Signed in.</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/login">Login </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/register">Signup</a>
                        </li>

                    <%}else{%>
                        <li class = 'nav-item'>
                            <a href = '#'>Signed in as: <%=currentUser.username%></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/logout">Logout</a>
                        </li>
                    <%}%> -->
                </ul>
            </div>
        </nav>

        <div style = 'margin-top: 1rem' class = 'container'>
            <!-- <%if(error && error.length > 0){%>
                <div class="alert alert-danger" role="alert">
                    <%=error%>
                </div>
            <%}%>
            <%if(success && success.length > 0){%>
                <div class="alert alert-success" role="alert">
                    <%=success%>
                </div>
            <%}%> -->
        </div>



    </header>

    <div class="container bg-light mt-5 py-5 w-100">
        <form action='/login' method='POST'>
            <center>
            <h1>
                LoginPage
            </h1>
            </center>
            <br><br>
            <div class="row md-12 d-flex justify-content-center">
                <input class="mx-5 w-25 my-2 form-control"  type='text' name='username' placeholder='Enter Username'>
            </div>
            <div class="row md-12 d-flex justify-content-center">
                <input class="mx-5 my-2 w-25 form-control" type='password' name='password' placeholder='........'>
            </div>
            <div class="row md-12 d-flex justify-content-center">
                <button class="w-25 my-3 bg-primary rounded text-light border border-light p-1"  type="submit">Login</button>
            </div>
        </form>
    </div>
</body>
</html> <?php /**PATH C:\Users\AbdulMunim\laravel\YelpCamp\resources\views/LoginPage.blade.php ENDPATH**/ ?>