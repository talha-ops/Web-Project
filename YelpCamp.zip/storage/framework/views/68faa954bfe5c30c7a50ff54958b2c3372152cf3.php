<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>YelpCamp</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <!-- <script src="<?php echo e(asset('js/app.js')); ?>" defer></script> -->
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/campgrounds')); ?>">
                    YelpCamp
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">
                        
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <section>
        <div class="container mt-5">
            <div class="row">
                <div class="col-md-12">
                    <div class="img-thumbnail" style="width: auto; height: auto;">
                        <img class="mt-1 ml-1 img-fluid w-100 h-100 figure-img rounded"  src="<?php echo e($campgroundDetail->imageUrl); ?>"
                            alt="IMG">
                        <div class="figure w-100">
                            <figcaption class="figure-caption" style="float: right;">
                                <h4> <?php echo e($campgroundDetail->money); ?></h4>
                            </figcaption>
                            <h4><a href=""> <?php echo e($campgroundDetail->name); ?></a></h4>
                            <p>
                                <?php echo e($campgroundDetail->description); ?>

                            </p>
                            <?php if($userid == $campgroundDetail->userId): ?>
                                <div class="text-right">
                                    <a class="btn btn-success" href="/campground/campground-detail/edit-campground/<?php echo e($campgroundDetail->id); ?>">
                                        Edit Info
                                    </a>
                                </div>
                            <?php endif; ?>
                            <?php if($userid == $campgroundDetail->userId): ?>
                                <div class="text-right mt-3">
                                    <form action="/campground/campground-detail/<?php echo e($campgroundDetail->id); ?>/delete" method="post">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger">
                                            Delete CampGround
                                        </button>
                                    </form>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div style="height: 50px;">

                    </div>
                    <div class="well bg-light px-3 py-3">

                        <form id="comment_form">
                            <?php echo csrf_field(); ?>
                            <button type ="submit" class="text-right btn btn-success" id="add-comment" >
                                Add Comment
                            </button>
                            <div class="mt-4" style="width: 100%; margin: 0 auto;">
                                <input class="form-control" type="text" placeholder="Write your Experience" name="comment", id="comment">
                            </div>
                        </form>
                        <hr>
                        <!--Comment Structure-->
                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mt-3 px-3 py-3">
                                <div class="row">
                                    <div class="col-md-12">
                                        <h4 style="display: inline;"><?php echo e($comment->username); ?></h4>
                                        <h6 class="text-right" style="display: inline; float:right"><?php echo e($comment->created_at); ?></h6>
                                        <p class="mt-4">
                                            <?php echo e($comment->comment); ?>

                                        </p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="px-3 py-3" id="commentside">
                            
                        </div>
                    </div>
                    
                </div>
                
            </div>
        </div>
    </section>
    <script> 
        
        $("#comment_form").submit(function(e){
            // let comments = document.getElementById('#comment').innerHTML;
            var comments = $('#comment').val();
            e.preventDefault();
            $.ajax({
                url: "/campground/campground-detail/<?php echo e($campgroundDetail->id); ?>",
                type: "POST",
                data:{
                    comment:comments,
                },
                beforeSend: function(xhr, type) {
                    if (!type.crossDomain) {
                        xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
                    }
                },
                success:function(response){
                    if(response){
                        $("#commentside").append(
                           "<div class='row mt-4' >"+
                                "<div class='col-md-12'>"+
                                    "<h4 style='display: inline;'>"+ response.username +"</h4>"+
                                    "<h6 class='text-right' style='display: inline; float:right'>"+ response.created_at+"</h6>"+
                                    "<p class='mt-4'>"+ response.comment +"</p>"+
                                    "</div>"+
                            "</div>"
                        );
                    }
                    $('#comment').val('');
                }
            });
        });
    </script>   

</body>
</html>


<?php /**PATH C:\Users\AbdulMunim\laravel\YelpCamp\resources\views/campgrounds-detail.blade.php ENDPATH**/ ?>