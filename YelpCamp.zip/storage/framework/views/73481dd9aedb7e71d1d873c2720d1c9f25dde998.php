<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>YelpCamp</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
</head>

<body>
    <header>
        <nav class="navbar navbar-light bg-light navbar-expand-sm">
            <div class="navbar-header mx-3">
                <a href="/" class="navbar-brand">Yelp Camp</a>
            </div>
            <button class="navbar-toggler" data-toggle="collapse" data-target="#options">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse d-flex flex-row-reverse mx-4" id="options">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="#">Login </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Signup</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Logout</a>
                    </li>
                </ul>
            </div>
        </nav>
    </header>
    <section>
        <div class="container col-sm-12 col-md-12 col-lg-12 col-xl-12 col-12">
            <div class="row">
                <h1 style="text-align: center;">
                    Create a New Campground
                </h1>
                <div style="width: 30%; margin: 0 auto;">
                    <form action="/campgrounds" method="POST">
                        <div class="mt-3">
                            <input class="form-control" type="text" name="name" placeholder="Name">
                        </div>
                        <div class="mt-3">
                            <input class="form-control" type="text" name="image" placeholder="Image Url">
                        </div>
                        <div class="mt-3" >
                            <button class="btn btn-lg btn-primary w-100">
                                Submit
                            </button>
                        </div>
                    </form>
                    <div class="mt-3">
                        <a href="/campgrounds">Go Back</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
        crossorigin="anonymous"></script>
</body>

</html><?php /**PATH C:\Users\AbdulMunim\laravel\YelpCamp\resources\views/createCampground.blade.php ENDPATH**/ ?>